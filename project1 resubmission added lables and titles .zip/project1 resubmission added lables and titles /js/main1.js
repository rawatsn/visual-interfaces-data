/**
 * Load TopoJSON data of the world and the data of the world wonders
 */

Promise.all([
        d3.json('data/counties-10m.json'),
        d3.csv('data/population.csv'),
        d3.csv('data/fipsnew.csv')

    ]).then(data => {
        const geoData = data[0];
        const countyPopulationData = data[1];
        const restdata = data[2].filter(function(d) { return d.year == 2021 });

        // Combine both datasets by adding the population density to the TopoJSON file
        console.log(geoData);
        geoData.objects.counties.geometries.forEach(d => {
            console.log(d);
            for (let i = 0; i < countyPopulationData.length; i++) {
                if (d.id === countyPopulationData[i].cnty_fips) {
                    d.properties.pop = +countyPopulationData[i].Value;
                }

            }

            for (let i = 0; i < restdata.length; i++) {
                if (d.id === restdata[i].cnty_fips) {
                    d.properties.maqi = +restdata[i].maqi;
                    d.properties.state = +restdata[i].state;
                    d.properties.medianaqi = +restdata[i].medianaqi;
                    d.properties.percentile = +restdata[i].percentile;
                    d.properties.DaysCO = +restdata[i].DaysCO;
                    d.properties.DaysNO2 = +restdata[i].DaysNO2;
                    d.properties.DaysOzone = +restdata[i].DaysOzone;
                    d.properties.DaysSO2 = +restdata[i].DaysSO2;
                    d.properties.DaysPM2_5 = +restdata[i].DaysPM2_5;
                    d.properties.DaysPM10 = +restdata[i].DaysPM10;

                }
            }
        });

        const choroplethMap = new ChoroplethMap({
            parentElement: '.viz',
        }, geoData);
    })
    .catch(error => console.error(error));